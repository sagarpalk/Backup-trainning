/*
 * package com.cybage.junit;
 * 
 * import static org.junit.Assert.*;
 * 
 * import org.junit.Test;
 * 
 * import com.cybage.model.Offer;
 * 
 * public class JUnitTestCase2 {
 * 
 * @Test public void testOffer() { //fail("Not yet implemented");
 * 
 * Offer offer = new Offer(); assert ("offer name") != null,
 * 
 * );
 * 
 * }
 * 
 * @Test public void testOfferInt() { fail("Not yet implemented"); }
 * 
 * @Test public void testOfferStringDouble() { fail("Not yet implemented"); }
 * 
 * @Test public void testOfferIntDouble() { fail("Not yet implemented"); }
 * 
 * @Test public void testOfferIntStringDouble() { fail("Not yet implemented"); }
 * 
 * @Test public void testGetO_offerid() { fail("Not yet implemented"); }
 * 
 * @Test public void testSetO_offerid() { fail("Not yet implemented"); }
 * 
 * @Test public void testGetO_name() { fail("Not yet implemented"); }
 * 
 * @Test public void testSetO_name() { fail("Not yet implemented"); }
 * 
 * @Test public void testGetO_rate() { fail("Not yet implemented"); }
 * 
 * @Test public void testSetO_rate() { fail("Not yet implemented"); }
 * 
 * @Test public void testToString() { fail("Not yet implemented"); }
 * 
 * }
 */