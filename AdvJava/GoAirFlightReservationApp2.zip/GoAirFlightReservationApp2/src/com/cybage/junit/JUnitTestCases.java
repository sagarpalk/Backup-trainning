/**
 * 
 */
package com.cybage.junit;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author sagarpalk
 *
 */
public class JUnitTestCases {

	/**
	 * Test method for {@link com.cybage.controller.LoginController#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)}.
	 */
	@Test
	public void testDoPostHttpServletRequestHttpServletResponse() {
		
	}

}
