$(document).ready(function(){
  $("h2").nextUntil("h5").css({"color": "red", "border": "2px solid red"});
});

$(document).ready(function(){
  $("h2").siblings("p").css({"color": "red", "border": "2px solid red"});
});

/*$(document).ready(function(){
  $("h2").next().css({"color": "red", "border": "2px solid red"});
});*/

/*$(document).ready(function(){
  $("h2").nextAll().css({"color": "red", "border": "2px solid red"});
});

$(document).ready(function(){
  $("h2").nextUntil("h6").css({"color": "red", "border": "2px solid red"});
});*/